//variaveis
//escopo global, escopo local
// var (escopo global) - define variável de escopo global, 
// let (dentro do bloco) - define variável de escopo local, 
// const - variável com valor fixo (constante)
// javascript é case sensitive

var nome = "Rafael"

if (true) {
	let nome = "anselmo"
	console.log(nome)
}
console.log(nome)

//apresenta erro pois é uma variável constante
const nome2 = "Ferreira"
if (true) {
	nome2 = "Coelho"
	console.log(nome)
}

