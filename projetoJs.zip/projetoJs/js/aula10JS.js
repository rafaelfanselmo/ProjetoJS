
/*
console.log(
	document.getElementById("p1").innerHTML
	)*/


var paragrafo = document.getElementById("p1");

//atribuindo novo valor 
paragrafo.innerHTML = "Novo Valor";

paragrafo.style.color = "red"
paragrafo.style.backgroundColor = "#333"
paragrafo.style.height = "100px"


var imagem = document.getElementById("imagem")
imagem.src = "C:/Users/usrafa/Documents/IPHG/projetoJs/js/teste.png"
imagem.alt = "Teste de imagem"
imagem.width = "600"

//cria um elemento para o html
var img = document.createElement("img")
img.src = "C:/Users/usrafa/Documents/IPHG/projetoJs/js/teste.png"
console.log(
	document.createElement("div"), 
	img
	)