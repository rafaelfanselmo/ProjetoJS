var p = document.createElement("p")
p.innerHTML = "Olha Pessoal"

var img = document.createElement("img")
img.src = "C:/Users/usrafa/Documents/IPHG/projetoJs/js/teste.png"

document.getElementById("conteudo").appendChild(p)
document.getElementById("conteudo").appendChild(img)

//document.getElementById("conteudo").removeChild(img)

// Exibe o Nos filhos da tag body em forma de lista
console.log(
	document.body.childNodes
	)


var lista = document.body.childNodes
// exibe o número de nos do Nodelista especificado
/alert(lista.length)

// exibe exata informação de acordo com o index
alert(lista[1].innerHTML)

// exibe exata informação de acordo com o nome
alert(lista[1].nodeName)

// exibe exata informação de acordo com o tipo
alert(lista[1].nodeType)

// exibe exata informação de acordo com o valor
alert(lista[1].nodeValue)

// exibe exata informação de acordo com o filhos do filho
alert(lista[3].childNodes[5])