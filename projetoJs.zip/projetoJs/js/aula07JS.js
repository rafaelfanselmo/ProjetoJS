//busca pelo atricuto id
console.log(
	document.getElementById("fruta").innerHTML
	)

//busca o atributo name
console.log(
	document.getElementsByClassName("carro")[1].innerHTML
	)

//busca pela tag do html
console.log(
	document.getElementsByTagName("div")[1]
	)

//busca pelo primeiro elemento que encontrar
//atenção pois há uma regra para cada atributo . ou # dependendo do atributo
console.log(
	document.querySelector(".carro")
	)
