// pega todos os elementos times
console.log(
	document.querySelectorAll(".times")
	)

//pega todos os elemntos da div específica
console.log(
	document.getElementById("futebol-europeu").querySelectorAll(".times")[0].innerHTML
	)
