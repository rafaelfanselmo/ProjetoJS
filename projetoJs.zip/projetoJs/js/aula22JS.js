//Array
// É uma estrutura de dados que armazena uma coleção de elementos

let meuarray = ['notebook','mouse','teclado']
console.log(meuarray)

let meuarray2 = [
	'notebook',
	15000.00,
	{memoria: '16GB',hd:'100GB'},
	['NoteDELL','Modelo 100']
]
console.log(meuarray2[2])
console.log(meuarray2[2].memoria)
console.log(meuarray2[3])
console.log(meuarray2[3][1])
