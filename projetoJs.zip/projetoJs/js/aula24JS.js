//operadores aritiméticos

let x = 10
let y = 5
let soma = y+x
console.log(x+y)
console.log(soma)

let sub = y-x
console.log(sub)

let div = y/x
console.log(div)

let mult = y*x
console.log(mult)

let exp = y**x
console.log(exp)

let modulo = x%y
console.log(modulo)

//x = x + y é igual a essa x +=y
//x = x - y é igual a essa x-=y 
//x = x / y é igual a essa x/=y
//x = x**y  é igual a essa x**=y
//x = x % y é igual a essa x%=y 
//
x-- // incremento
console.log(x)
x++ // decremento
console.log(x)