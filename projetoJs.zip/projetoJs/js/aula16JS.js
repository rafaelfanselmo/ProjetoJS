//adiciona e configura um atributo em uma tag
document.getElementById("btn-set").addEventListener("click", function () {
	document.getElementById("title").setAttribute("class", "red")
})

//remove um atributo em uma tag
document.getElementById("btn-remove").addEventListener("click", function () {
	document.getElementById("title").removeAttribute("class")
})

// pega o valor do atribudo e insere em outra tag
document.getElementById("btn-get").addEventListener("click", function () {
	var value = document.getElementById("title").getAttribute("class")
	document.getElementById("class").innerHTML = value
})

// Aula 17 - adicionando texto no elemento
var titulo = document.querySelector("h2")
var texto  = document.createTextNode("Appendando texto em um elemento")

//titulo.appendChild(texto)
titulo.textContent = "Também funciona para adicioanr texto em um elemtno"