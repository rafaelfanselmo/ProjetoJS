//window.alert("olhá mundo");
//window.console.log(window.document.getElementById('titulo').innerHTML);

console.log(
    screen.width
)

console.log(
    screen.height
)

console.log(
    screen.orientation.type
)

console.log(
 	navigator.appName
)
console.log(
 	//location.href  = "http://www.google.com" redireciona a página
 	location.href
)

console.log(
	history
)

function voltar(){
	history.back()
}

function adiantar(){
	history.forward()
}

document.getElementById('largura').innerHTML = screen.width
