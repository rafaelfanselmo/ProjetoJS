/*
Condicionais
If
Else
ElseIf
Switch
For
While
for in - para percorrer propriedade de um objeto
for of
*/

let pais = "Brasil"
let estado = "RS"


if (pais=="portugal") {
	console.log("sou brasileiro")
}else if (estado=="RS"){
	console.log("sou Gaucho")
}else{
	console.log("sou Estrangeiro")
}


switch(pais){
	case 'Brasil':
		console.log("Sim, Brasil")
		break
	case 'Canada':
		console.log("Opa, Canada")
		break
	default:
		console.log("Padrão")
		break
}

let paises = document.getElementsByClassName('pais')
let i = 0
/*
for (let i = 0; i <= paises.length; i++) {
	console.log(paises[i].innerHTML)
}
*/	
while(i < paises.length){
	console.log(paises[i].innerHTML)
		i++
}

let fruta = {
	nome: "Banana",
	preco:3.25,
	unidade:1
}

for (let valor in fruta) {
	console.log("for in - valor ", valor)
	console.log("for in - fruta: ", fruta)
	console.log("for in - fruta[valor]: ",fruta[valor])
}

let aparelhos = ["Celular", "Fonde ouvido", "Microfone","Radio"]

for (let valor of aparelhos) {
	console.log("for of - valor ", valor)
	
}