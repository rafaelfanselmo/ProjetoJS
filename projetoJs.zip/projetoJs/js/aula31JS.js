/*
Alert = método do window que recebe apenas um parâmetro
Prompt = método do window que recebe um parametro
Confirm = método do window que retorna true ou false
*/

window.alert("isso é um alert")

let nome=window.prompt("Digite seu Nome: isso é um prompt")

console.log(nome)
alert(nome)

document.getElementById("nome").innerHTML = nome

let confirma = confirm("Tem certeza que deseja excluir")
console.log(confirma)
if (confirma==true) {
	alert("item excluido com sucesso")
}else{
	alert("Item não excluido")
}