// busca os nos pai de acordo com o informado ou a sequencia de parentNode
console.log(
	document.getElementById("ilheus").parentNode.parentNode.parentNode
	)