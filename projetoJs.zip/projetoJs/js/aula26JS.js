/*
Operadores lógicos, coapração e operadores ternários
*/

let x = "5" 
let y = 8
let media = 8
let frequencia = 80
let idade = 16

let eleitor = (idade>=16? "Pode votar" : "Não pode Votar")
let eleitor2 = !(idade>=16)? "Pode votar" : "Não pode Votar"



console.log("para x = \"5\" então x===5 é ",x === 5)
console.log("para x = \"5\" então x==5 é ",x == 5)
console.log("para x = \"5\" então x!=5 é ",x != 5)
console.log("para x = \"5\" então x!==5 é ",x == 5)
console.log("para y = 8 então y==8 é ",y == 8)
console.log("para y = 8 então y!=8 é ",y != 8)
console.log("para y = 8 então y < 10 é ",y < 10)
console.log("para y = 8 então y > 8 é ",y > 10)
console.log("para y = 8 então y >= 8 é ",y >= 10)
console.log("para y = 8 então y <= 8 é ",y <= 10)
console.log("media = 8 e frequencia = 80 temos media>=7 && frequencia>=80 ",media>=7 && frequencia>=80)
console.log("media = 8 e frequencia = 80 temos media>=7 || frequencia>=80 ",media>=7 || frequencia>=80)
console.log("let eleitor = (idade>=16)? \"Pode votar\" : \"Não pode Votar\"",eleitor)
console.log("let eleitor = !(idade>=16)? \"Pode votar\" : \"Não pode Votar\"",eleitor2)




