//Objetos
/*
Um Objeto é uma coleção de propriedades, e uma
propriedade é uma associação ente um nome (ou chave)
e um valor. Um valor de propriedade pode ser uma função, que é então 
considerada um método de objeto
*/

let pessoa = {
	nome: "Anselmo",
	idade: 38,
	feliz: true,
	pets: ["dog","cat"],
	carros: {
		camaro: {
			placa : "123456",
			cor : "verde"
		},
		uno: {
			placa: "98765454",
			cor: "vermelho"
		}
	},
	andar: function(km) {
		alert(pessoa.nome+" andou "+km+" km!")
	}
}

pessoa.andar(20)


console.log(pessoa)
console.log(pessoa.nome)
console.log(pessoa.pets)
console.log(pessoa.pets[0])

// alterando valores
pessoa.nome = "Joaquin"
pessoa.pets[0] = "Passaros"
console.log(pessoa.nome)
console.log(pessoa.pets[0])

// acessando outros objetos
console.log(pessoa.carros.camaro)
console.log(pessoa.carros.camaro.cor)
console.log(pessoa.carros.uno.placa)