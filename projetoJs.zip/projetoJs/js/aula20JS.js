//tipos dados

//string
var nome = "Rafael"
var nome2 = 'Rafael Ferreira'
alert(typeof(nome))

//number
var idade = 50
alert(typeof(idade))
var num = 55.55
alert(typeof(num))

//boolean
var solteiro = true
alert(typeof(solteiro))

// array
var frutas = ["goiaba","maçã","banana"]
//alert(typeof(frutas))

// object
var carro = new Object()
carro.fabricacao = "2025"
carro.cor = "azul"

alert(carro.cor)

// function
var soma = function(a,b){return a+b}

alert(soma(5,15))
alert(typeof(soma))
alert(typeof(soma(5,15)))