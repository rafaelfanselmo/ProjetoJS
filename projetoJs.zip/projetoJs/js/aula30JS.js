/*
Functions
*/

function exibirAlert(){
	alert("Função chamando alert() ")
}
exibirAlert()

function soma(){
	return 5+8
}
console.log("Função sem aprâmetro: ",soma())

function somaParam(x,y){
	return x,y
}
console.log("Função com parâmetro: ",somaParam(6,23))

function somaParamParaHtml(x,y){
	return x,y
}

document.getElementById("result").innerHTML = somaParamParaHtml(36,85)